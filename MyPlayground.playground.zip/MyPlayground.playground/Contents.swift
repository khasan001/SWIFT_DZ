import Foundation


enum MotorOil: String {
    case valvoline = "Valvoline"
    case mobil = "Mobil"
    case castrol = "Castrol"
    case shell = "Shell"
}

struct Stantion {
    var oilBrand: MotorOil = .valvoline
    
    
    static func create(with motorOliBrand: String) -> Stantion? {
        if let oil = MotorOil(rawValue: motorOliBrand) { // проверяем если ли масляный бренд, который соответсвует строке, переданной в функцию
            var stantion = Stantion()
            stantion.oilBrand = oil
            return stantion
        } else {
            return nil
        }
    }
}

let audiStation = Stantion.create(with: "Castrol")
let kiaStation = Stantion.create(with: "Zic")


enum IntErrors: String, Error {
    case ten =  " Меньше десяти поднажми"
    case twenty = "еще немного"
    case thirty = "Самая малость"
}



    
func x(_ e: Int) throws -> Int {
    
    if e <= 10 {
        throw IntErrors.ten
    } else if e <= 20 {
        throw IntErrors.twenty
    } else if e <= 30 {
        throw IntErrors.thirty
    } else {
        return e + 1
    }
}

var number: Int?

do {
    number = try x(3)
} catch {
    if let error = error as? IntErrors {
        print(error.rawValue)
}
}
